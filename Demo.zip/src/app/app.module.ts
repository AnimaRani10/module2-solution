import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { DashBoardComponent } from './DashBoard/dash-board.component';
import { VehicleComponent } from './vehicles/vehicle.component';
import { CharacterComponent } from './characters/character.component';
import { NavBarComponent } from './NavBar/nav-bar.component';
import { employeeDetailsComponent } from './employeeDetails/employeeDetails.component';
import { EmployeeService } from './employeeDetails/employeeDetails.service';

@NgModule({
  declarations: [
    AppComponent,
    DashBoardComponent,
    CharacterComponent,
    VehicleComponent,
    NavBarComponent,
    employeeDetailsComponent
   
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'Home' , component: NavBarComponent},
      {path: 'EmployeeDetails' , component: employeeDetailsComponent},      
      {path: 'Dashboard' , component: DashBoardComponent},
      {path: 'Charcter' , component: CharacterComponent},
      {path: 'Vehicle' , component: VehicleComponent},
      {path: '' , redirectTo: 'Home' , pathMatch : 'full'}
    ])
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
