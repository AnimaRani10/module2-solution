import { Component } from "@angular/core";

@Component ({
    selector : 'pm-character',
    templateUrl : './character.component.html',
    styleUrls : ['./character.component.css']
})

export class CharacterComponent {

    

}