import { Component } from "@angular/core";
import { EmployeeService } from "../employeeDetails/employeeDetails.service";

@Component ({
    selector : 'dash-detail',
    templateUrl : './dash-board.component.html',
    styleUrls : ['./dash-board.component.css']
})

export class DashBoardComponent {





}