import { Component, OnInit } from "@angular/core";
import {EmployeeService} from "./employeeDetails.service"

@Component ({
    selector : 'employee-detail',
    templateUrl : './employeeDetails.component.html',
    styleUrls : ['./employeeDetails.component.css']
})

export class employeeDetailsComponent implements OnInit {
    temp
  
   constructor(private employee:EmployeeService){}


    ngOnInit(): void{
       this.employee.getEmployee().subscribe(data=>{
           this.temp=data
           console.log(this.temp)
       })

        }
        
        
    }
