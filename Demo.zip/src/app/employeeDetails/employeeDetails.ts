export interface IEmployee {
    employeeId: number,
    employeeName: string,
    employeeCode: string,
    employeeJoiningDate: string,
    city: string,       
    employeeRating:number
}