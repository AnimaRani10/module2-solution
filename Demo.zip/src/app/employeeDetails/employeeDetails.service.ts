import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { IEmployee } from "./employeeDetails";



@Injectable()

export class EmployeeService {
 
    private _url = "./api/details/employee.json";
    constructor(private http: HttpClient) {  }

    getEmployee(){
        return this.http.get<IEmployee>(this._url);
       
    }


}