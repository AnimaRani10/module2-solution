import { Component } from "@angular/core";

@Component ({
    selector : 'pm-vehicle',
    templateUrl : './vehicle.component.html',
    styleUrls : ['./vehicle.component.css']
})

export class VehicleComponent {


}