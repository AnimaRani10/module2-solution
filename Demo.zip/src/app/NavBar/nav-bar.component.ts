import { Component } from "@angular/core";

@Component ({
    selector : 'pm-nav',
    templateUrl : './nav-bar.component.html',
    styleUrls : ['./nav-bar.component.css']
})

export class NavBarComponent {

    title: string = 'Tracker';

}